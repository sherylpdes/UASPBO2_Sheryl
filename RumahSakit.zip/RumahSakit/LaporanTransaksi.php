<?php 
error_reporting(0);
include "koneksi.php";
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>LAPORAN TRANSAKSI</title>
    <style>
        .judul{
            margin-top: 10px;
            color: black;
        }

        .text-center{
            margin-top: 20px;
        }

        .col-form-label{
            font-weight: bold;
        }

        .btn-primary{
            font-weight: bold;
        }

        .print-button {
            margin-top: 20px;
            margin-left: 90%;
        }

        .tanggal{
            margin-top: 10px;
            text-align: center;
        }

        .table-bordered{
            margin-top: 10px;
        }

        .thead-dark{
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2 class="judul">LAPORAN TRANSAKSI</h2>
            </div>
        </div>

        <form method="post" class="text-center">
            <div class="form-group row">
                <label for="dari" class="col-sm-2 col-form-label">Dari Tanggal</label>
                <div class="col-sm-4">
                    <input type="date" name="dari" id="dari" class="form-control">
                </div>
                <label for="sampai" class="col-sm-2 col-form-label">Sampai Tanggal</label>
                <div class="col-sm-4">
                    <input type="date" name="sampai" id="sampai" class="form-control">
                </div>
            </div>
            <button type="submit" name="cek" class="btn btn-primary">Cek Data</button>
        </form>

        <a href="javascript:window.print()" class="btn btn-success print-button">
            <img src="img/print.jpg" alt="print" class="img-thumbnail" height="30" width="50">
            Print
        </a>

        <div class="tanggal">
        <?php 
            if (isset($_POST['cek'])) {
                $dari = $_POST['dari'];
                $sampai = $_POST['sampai'];
                echo "<h5>Tanggal $dari sampai Tanggal $sampai</h5>";
            }
            ?>
        </div>

        <div class="row mt-4">
            <div class="col-md-12">
                <table class="table table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>No. Reff</th>
                            <th>No. RM</th>
                            <th>Nama Pasien</th>
                            <th>Kode Poli</th>
                            <th>Nama Poli</th>
                            <th>Nama Dokter</th>
                            <th>Jenis Biaya</th>
                            <th>Jumlah Biaya</th>
                            <th>Bayar</th>
                            <th>Kembali</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php 
                        $where = "";
                        if (isset($_POST['cek'])) {
                            $dari = $_POST['dari'];
                            $sampai = $_POST['sampai'];
                            $where = "WHERE tanggal BETWEEN '$dari' AND '$sampai'";
                        }

                        $sql = "SELECT * FROM tbl_transaksi $where";
                        $query = mysqli_query($con, $sql);
                        while ($r = mysqli_fetch_array($query)) {
                        ?>
                        <tr>
                            <td><?php echo $r['no_reff'] ?></td>
                            <td><?php echo $r['no_rm'] ?></td>
                            <td><?php echo $r['nama_pasien'] ?></td>
                            <td><?php echo $r['kode_poli'] ?></td>
                            <td><?php echo $r['nama_poli'] ?></td>
                            <td><?php echo $r['nama_dokter'] ?></td>
                            <td><?php echo $r['jenis_biaya'] ?></td>
                            <td>Rp. <?php echo number_format($r['jumlah_biaya']) ?></td>
                            <td>Rp. <?php echo number_format($r['bayar']) ?></td>
                            <td>Rp. <?php echo number_format($r['kembali']) ?></td>
                            <td><?php echo $r['tanggal'] ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
