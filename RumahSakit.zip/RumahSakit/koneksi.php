<?php

$host = "localhost";
$port = "3306";
$user = "root";
$pass = "";
$db = "dbrumahsakit";

$con = mysqli_connect($host, $user, $pass, $db);

if (!$con) {
    die("Koneksi gagal: " . mysqli_connect_error());
}else{
    // echo "Koneksi berhasil";
}