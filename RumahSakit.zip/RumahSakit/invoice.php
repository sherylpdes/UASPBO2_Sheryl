<?php
include "koneksi.php";
 
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>INVOICE PEMBAYARAN HEARTLAND MEDICAL CENTRE</title>
    
    <style>
        .invoice-box {
            max-width: 800px;
            margin: auto;
            padding: 10px;
            border: 1px solid #eee;
            box-shadow: 0 0 10px rgba(0, 0, 0, .15);
            font-size: 16px;
            line-height: 24px;
            font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
            color: #555;
        }

        .invoice-box table {
            width: 100%;
            line-height: inherit;
            text-align: left;
        }

        .invoice-box table td {
            padding: 5px;
            vertical-align: top;
        }

        .invoice-box table tr td:nth-child(2) {
            text-align: right;
        }

        .invoice-box table tr.top table td {
            padding-bottom: 10px;
        }

        .invoice-box table tr.top table td.title {
            font-size: 22px;
            font-weight: bold;
            line-height: 45px;
            color: #333;
            text-align: center;
        }

        .invoice-box table tr.information table td {
            padding-bottom: 40px;
        }

        .invoice-box table tr.heading td {
            text-align: left;
        }

        .invoice-box table tr.details td {
            padding-bottom: 20px;
        }

        .invoice-box table tr.item td {
            border-bottom: 1px solid #eee;
            text-align: center;
        }

        .invoice-box table tr.total td:nth-child(2) {
            border-top: 2px solid #eee;
            font-weight: bold;
        }

        @media only screen and (max-width: 600px) {
            .invoice-box table tr.top table td,
            .invoice-box table tr.information table td {
                width: 100%;
                display: block;
                text-align: center;
            }
        }

        .receipt-footer {
            text-align: center;
            margin-top: 20px;
            border-top: 1px solid #eee;
            padding-top: 20px;
        }

        .title, .mid {
            text-align: center;
        }

        .mid {
            font-weight: bold;
        }

        .daftar {
            text-align: center;
        }

        .item {
            text-align: left;
        }

        .total, .bayar, .kembali {
            text-align: right;
        }
    </style>
</head>

<body onload="window.print()">
    <div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
            <tr class="top">
                <td colspan="5">
                    <table>
                        <tr>
                            <td class="title">
                                <p>HEARTLAND MEDICAL CENTRE</p>
                                <p> Jl. Pondok Raya VII No. 15 Angkasa Pura<br>
                                Jayapura, Papua </p>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <tr class="mid">
                <td colspan="5">TAGIHAN RUMAH SAKIT</td>
            </tr>
            
            <?php
                // Fetch transaction data
                $query = mysqli_query($con,"SELECT * FROM tbl_transaksi WHERE no_reff = '$_GET[reff]'");
                $data = mysqli_fetch_array($query);
            ?>

            <tr class="heading">
            <td>No. Reff</td>
            <td><?php echo $data['no_reff']; ?></td>
                <td>Tanggal</td>
                <td><?php echo $data['tanggal']; ?></td>
            </tr>
            
            <tr class="heading">
                <td>No. RM</td>
                <td><?php echo $data['no_rm']; ?></td>
                <td>Nama Dokter</td>
                <td><?php echo $data['nama_dokter']; ?></td>
            </tr>

            <tr class="heading">
                <td>Nama Pasien</td>
                <td><?php echo $data['nama_pasien']; ?></td>
                <td>Kode Poli</td>
                <td><?php echo $data['kode_poli']; ?></td>
            </tr>

            <tr class="heading">
                <td>Nama Poli</td>
                <td><?php echo $data['nama_poli']; ?></td>
            </tr>

            <tr class="mid">
                <td colspan="5">TINDAKAN DAN LAYANAN MEDIS</td>
            </tr>
            
            <table>
                <thead>
                    <tr class="daftar">
                        <th>No</th>
                        <th>Layanan</th>
                        <th>Biaya</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    $no = 0;
                    $results = mysqli_query($con, "SELECT * FROM tbl_transaksi WHERE no_reff = '$_GET[reff]'");
                    
                    while ($rows = mysqli_fetch_assoc($results)) {
                        $no++;
                    ?>
                        <tr class="item">
                            <td><?php echo $no; ?></td>
                            <td><?php echo $rows['jenis_biaya']; ?></td>
                            <td>Rp. <?php echo number_format($rows['jumlah_biaya']); ?></td>
                        </tr>
                    <?php
                    }
                    ?>
                    <tr>
                        <td colspan="5" class="total">Grand Total</td>
                        <?php
                        $a = mysqli_query($con, "SELECT SUM(jumlah_biaya) as TOTAL FROM tbl_transaksi WHERE no_reff='$_GET[reff]'");
                        $total = mysqli_fetch_array($a);
                        ?>
                        <td><?php echo $total['TOTAL']; ?></td>
                    </tr>
                    <tr>
                        <td colspan="5" class="bayar">Bayar</td>
                        <?php
                        $b = mysqli_query($con, "SELECT bayar FROM tbl_transaksi WHERE no_reff='$_GET[reff]'");
                        $bayar = mysqli_fetch_array($b);
                        ?>
                        <td><?php echo $bayar['bayar']; ?></td>
                    </tr>
                    <tr>
                        <td colspan="5" class="kembali">Kembali</td>
                        <?php
                        $c = mysqli_query($con, "SELECT kembali FROM tbl_transaksi WHERE no_reff='$_GET[reff]'");
                        $kembali = mysqli_fetch_array($c);
                        ?>
                        <td><?php echo $kembali['kembali']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="receipt-footer">
            <p>==============================================</p>
            <p><strong>HEARTHLAND MEDICAL CENTRE</strong></p>
            <p>Terima Kasih sudah Datang! Semoga Lekas Sembuh!</p>
        </div>
    </div>
</body>
</html>